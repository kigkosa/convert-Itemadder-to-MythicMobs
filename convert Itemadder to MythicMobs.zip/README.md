## convert Itemadder to MythicMobs
Free! by <a href="https://www.facebook.com/HelloWorldCH">HelloWorld</a>


1. เปิดไฟล์ \ItemsAdder\storage\items_ids_cache.yml
2. คัดลอกไอดีที่ต้องการแปลงลงในไฟล์ ia.txt <b>(มีตัวอย่างอยู่ในนั่นอย่าลืมลบออกละ)</b>
3. เปิดไฟล์ run.py ขึ้นมาแก้ <br>
    `file_name = '<ชื่อที่ต้องการ>'`
4. กดรันไฟล์ มันก็จะเจนไฟล์ออกมาเอาไว้ใช้กับ MythicMobs ไอเทมได้

